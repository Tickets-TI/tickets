 <div class="cont-in">
                                        <p><a href="#">Usuario Nombre</a></p>
                                        <div class="tbl img-comment">
                                            <div class="tbl-row">
                                                <div class="tbl-cell tbl-cell-img">
                                                    <img src="http://placehold.it/120x80" alt=""/>
                                                </div>
                                                <div class="tbl-cell tbl-cell-txt">
                                                    Descripción
                                                </div>
                                            </div>
                                        </div>
                                        <ul class="meta">
                                            <li><a href="#"></a></li>
                                            <li><a href="#"></a></li>
                                        </ul>
                                    </div>